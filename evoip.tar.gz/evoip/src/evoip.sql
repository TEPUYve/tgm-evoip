-- Table: codec
-- DROP TABLE codec;
CREATE TABLE codec
(
  id serial NOT NULL,
  descripcion character varying(300),
  velocidad numeric(10,3),
  valorie numeric(10,3),
  CONSTRAINT pk_codec PRIMARY KEY (id)
) 
WITHOUT OIDS;
ALTER TABLE codec OWNER TO postgres;

-- Table: protocolo
-- DROP TABLE protocolo;

CREATE TABLE protocolo
(
  id serial NOT NULL,
  descripcion character varying(300),
  qos boolean,
  CONSTRAINT pk_protocolo PRIMARY KEY (id)
) 
WITHOUT OIDS;
ALTER TABLE protocolo OWNER TO postgres;


-- Table: jitter
-- DROP TABLE jitter;
CREATE TABLE jitter
(
  id serial NOT NULL,
  descripcion character varying(300),
  cotaInf numeric (10,3),
  cotaSup numeric (10,3),
  CONSTRAINT pk_jitter PRIMARY KEY (id)
) 
WITHOUT OIDS;
ALTER TABLE jitter OWNER TO postgres;

-- Table: perdidapaquete
-- DROP TABLE perdidapaquete;
CREATE TABLE perdidapaquete
(
  id serial NOT NULL,
  descripcion character varying(300),
  cotaInf numeric (10,3),
  cotaSup numeric (10,3),
  CONSTRAINT pk_perdidapaquete PRIMARY KEY (id)
) 
WITHOUT OIDS;
ALTER TABLE perdidapaquete OWNER TO postgres;

-- Table: latencia
-- DROP TABLE latencia;
CREATE TABLE latencia
(
  id serial NOT NULL,
  descripcion character varying,
  cotaInf numeric (10,3),
  cotaSup numeric (10,3),
  CONSTRAINT pk_latencia PRIMARY KEY (id)
) 
WITHOUT OIDS;
ALTER TABLE latencia OWNER TO postgres;

INSERT INTO jitter (descripcion,cotaInf,cotaSup) VALUES ('EXCELENTE',-50,9.9);
INSERT INTO jitter (descripcion,cotaInf,cotaSup) VALUES ('BUENO',10,19.9);
INSERT INTO jitter (descripcion,cotaInf,cotaSup) VALUES ('ACEPTABLE',20,49.9);
INSERT INTO jitter (descripcion,cotaInf,cotaSup) VALUES ('POBRE',50,1000);


INSERT INTO latencia (descripcion,cotaInf,cotaSup) VALUES ('EXCELENTE',-300,49.9);
INSERT INTO latencia (descripcion,cotaInf,cotaSup) VALUES ('BUENO',50,149.9);
INSERT INTO latencia (descripcion,cotaInf,cotaSup) VALUES ('ACEPTABLE',150,299.9);
INSERT INTO latencia (descripcion,cotaInf,cotaSup) VALUES ('POBRE',300,3000);

INSERT INTO perdidapaquete (descripcion,cotaInf,cotaSup) VALUES ('EXCELENTE',0,0.09);
INSERT INTO perdidapaquete (descripcion,cotaInf,cotaSup) VALUES ('BUENO',0.1,0.49);
INSERT INTO perdidapaquete (descripcion,cotaInf,cotaSup) VALUES ('ACEPTABLE',0.5,1.49);
INSERT INTO perdidapaquete (descripcion,cotaInf,cotaSup) VALUES ('POBRE',1.5,100);



-- Table: eval
-- DROP TABLE eval;
CREATE TABLE eval
(
  id serial NOT NULL,
  descripcion character varying(300),
  anchobanda numeric(10,3),
  idcodec integer,
  idprotocolo integer,
  cantusuario integer,
  jitter numeric (10,3),
  latencia numeric (10,3),
  perdidapaquete numeric (10,3),  	
  CONSTRAINT pk_eval PRIMARY KEY (id),
  CONSTRAINT fk_eval_protocolo FOREIGN KEY (idcodec)
      REFERENCES codec (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION,
  CONSTRAINT fk_eval_procolo FOREIGN KEY (idprotocolo)
      REFERENCES protocolo (id) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
) 
WITHOUT OIDS;
ALTER TABLE eval OWNER TO postgres;


INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.711',64,0);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.726, G.727',40,2);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.721 (1988),G.726, G.727',32,7);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.726, G.727',24,25);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.726, G.727',16,50);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.728',16,7);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.728',12.8,20);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.729',8,10);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.729-A + VAD',8,11);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('IS-54',8,20);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('IS-641',7.4,10);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('IS-96a',8,21);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('IS-127',8,6);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('PDC Japon�s',6.7,24);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('GSM 06.10, velocidad plena',13,20);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('GSM 06.20, velocidad media',5.6,23);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('GSM 06.60, velocidad plena mejorada',12.2,5);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.723.1',5.3,19);
INSERT INTO codec (descripcion,velocidad,valorie) VALUES ('G.723.1',6.3,15);


INSERT INTO protocolo(descripcion, qos)  VALUES ('PROTOCOLO A', TRUE);
INSERT INTO protocolo(descripcion, qos)  VALUES ('PROTOCOLO B', TRUE);

