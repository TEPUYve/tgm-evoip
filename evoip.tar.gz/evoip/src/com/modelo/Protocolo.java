package com.modelo;

import java.io.Serializable;

public class Protocolo implements Serializable {

	
	private static final long serialVersionUID = -7494476814764284468L;
	private int id ;
	private String descripcion;
	private boolean  qos;
	
	
	
	public Protocolo(int id, String descripcion, boolean qos) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.qos = qos;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public boolean isQos() {
		return qos;
	}
	public void setQos(boolean qos) {
		this.qos = qos;
	}
	
	public String toString() {
		
		return this.descripcion.toUpperCase();
	}
}
