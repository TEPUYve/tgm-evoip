package com.modelo;

import java.io.Serializable;

public class Codec implements Serializable{
	
	private static final long serialVersionUID = -3090685042775472307L;
	private int id;
	private String descripcion;
	private double velocidad;
	private  double valorIE;
	  
	public Codec(int id, String descripcion, double velocidad,
			double valorIE) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.velocidad = velocidad;
		this.valorIE = valorIE;
	}

  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public double getVelocidad() {
		return velocidad;
	}
	
	public String getVelocidadString() {
		return velocidad+" Kbps";
	}
	
	public void setVelocidad(double velocidad) {
		this.velocidad = velocidad;
	}
	public double getValorIE() {
		return valorIE;
	}
	public void setValorIE(double valorIE) {
		this.valorIE = valorIE;
	}
	@Override
	public String toString() {
	
		return this.descripcion.toUpperCase() + " ("+velocidad+" Kbit/s)";
	}

}
