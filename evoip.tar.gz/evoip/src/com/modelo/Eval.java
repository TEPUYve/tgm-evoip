package com.modelo;

import java.io.Serializable;
import java.text.DecimalFormat;

public class Eval implements Serializable {

	
	private static final long serialVersionUID = -7281637966073734592L;
	private int id;
	private String  descripcion;
	private double  anchobanda;
	private Codec codec;
	private Protocolo protocolo;
    private	int cantidadUsuarios;
	private double jitter;
	private double latencia;
	private double  perdidaPaquete;
	
	
	
	
	public Eval(int id, String descripcion, double anchobanda, Codec codec,
			Protocolo protocolo, int cantidadUsuarios, double jitter,
			double latencia, double perdidaPaquete) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.anchobanda = anchobanda;
		this.codec = codec;
		this.protocolo = protocolo;
		this.cantidadUsuarios = cantidadUsuarios;
		this.jitter = jitter;
		this.latencia = latencia;
		this.perdidaPaquete = perdidaPaquete;
	}
	public Eval() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public double getAnchobanda() {
		return anchobanda;
	}
	
	public String getAnchobandaString() {		
		return new DecimalFormat("#0.00").format(this.anchobanda)+" mb";
	}
	public void setAnchobanda(double anchobanda) {
		this.anchobanda = anchobanda;
	}
	public Codec getCodec() {
		return codec;
	}
	public void setCodec(Codec codec) {
		this.codec = codec;
	}
	public Protocolo getProtocolo() {
		return protocolo;
	}
	public void setProtocolo(Protocolo protocolo) {
		this.protocolo = protocolo;
	}
	public int getCantidadUsuarios() {
		return cantidadUsuarios;
	}
	
	public String getCantidadUsuariosString() {
		return cantidadUsuarios+"";
	}
	public void setCantidadUsuarios(int cantidadUsuarios) {
		this.cantidadUsuarios = cantidadUsuarios;
	}
	public double getJitter() {
		return jitter;
	}
	
	public String getJitterString() {
		return new DecimalFormat("#0.00").format(this.jitter)+" ms";
	}
	public void setJitter(double jitter) {
		this.jitter = jitter;
	}
	public double getLatencia() {
		return latencia;
	}
	
	public String getLatenciaString() {
		return new DecimalFormat("#0.00").format(this.latencia)+" ms";
	}
	public void setLatencia(double latencia) {
		this.latencia = latencia;
	}
	public double getPerdidaPaquete() {
		//return perdidaPaquete/100;
		return perdidaPaquete;
	}
	
	public String getPerdidaPaqueteString() {
		return new DecimalFormat("#0.00").format(this.perdidaPaquete)+" %";
	}
	
	public void setPerdidaPaquete(double perdidaPaquete) {
		this.perdidaPaquete = perdidaPaquete;
	}
}
