package com.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class SalidaEvaluacion implements Serializable{

	private static final long serialVersionUID = -8570462602701575342L;
	private Eval evaluacion;
	private double anchoBandaRequerido;
	private	Jitter jitter;
	private Latencia latencia;
	private PerdidaPaquete perdidaPaquete; 
	private String valoracionMOSyR = "NO SE PUDO DETERMINAR";
	private String valoracionJitter = "NO SE PUDO DETERMINAR";
	private String valoracionLatencia = "NO SE PUDO DETERMINAR";
	private String valoracionPerdidaPaquete = "NO SE PUDO DETERMINAR";
	private String valoracionAnchoBanda ="";
	private double R, Mos;
	
	public SalidaEvaluacion(Eval eval, double R, double MOS){
		this.evaluacion = eval;
		this.R = R;
		this.Mos = MOS;		
		if (R<= 0)
			Mos = 1.0;
		if (R>0 && R<100){
			Mos = 1+ 0.035 * R +7*R*(R-60)*(100-R)*0.000001;
						
			BigDecimal big = new BigDecimal(Mos);
			big = big.setScale(1, RoundingMode.HALF_UP);
			Mos = Double.parseDouble(""+big);
		}
		if (R>=100)
			Mos = 4.5;
		
		
		
		if (Mos<=2.6 && R<=50) this.valoracionMOSyR ="NO RECOMENDADO";
		if ((Mos>2.6 && Mos <=3.1) && (R>50&& R<=60)) this.valoracionMOSyR ="CASI TODOS LOS USUARIOS INSATISFECHOS";
		if ((Mos>3.1 && Mos <=3.6) && (R>60&& R<=70)) this.valoracionMOSyR ="MUCHOS USUARIOS INSATISFECHOS";
		if ((Mos>3.6 && Mos <=4.0) && (R>70&& R<=80)) this.valoracionMOSyR ="ALGUNOS USAURIOS INSATISFECHOS";
		if ((Mos>4.0 && Mos <=4.3) && (R>80&& R<=90)) this.valoracionMOSyR ="USUARIOS SATISFECHOS";
		if (Mos>4.3 && R>90) this.valoracionMOSyR ="USUARIOS MUY SATISFECHOS";
		
		this.anchoBandaRequerido = (this.evaluacion.getCantidadUsuarios()*this.evaluacion.getCodec().getVelocidad())/1024;
		
		if (this.evaluacion.getJitter() < 10) this.valoracionJitter ="EXCELENTE";
		if (this.evaluacion.getJitter() >= 10 && this.evaluacion.getJitter() < 20) this.valoracionJitter ="BUENO";
		if (this.evaluacion.getJitter() >= 20 && this.evaluacion.getJitter() < 50) this.valoracionJitter ="ACEPTABLE";
		if (this.evaluacion.getJitter() >= 50) this.valoracionJitter ="POBRE";
		
		if (this.evaluacion.getLatencia() < 50) this.valoracionLatencia ="EXCELENTE";
		if (this.evaluacion.getLatencia() >= 50 && this.evaluacion.getLatencia() < 150) this.valoracionLatencia ="BUENO";
		if (this.evaluacion.getLatencia() >= 150 && this.evaluacion.getLatencia() < 300) this.valoracionLatencia ="ACEPTABLE";
		if (this.evaluacion.getLatencia() >= 300) this.valoracionLatencia ="POBRE";
		
		if (this.evaluacion.getPerdidaPaquete() < 0.1) this.valoracionPerdidaPaquete ="EXCELENTE";
		if (this.evaluacion.getPerdidaPaquete() >= 0.1 && this.evaluacion.getPerdidaPaquete() < 0.5) this.valoracionPerdidaPaquete ="BUENO";
		if (this.evaluacion.getPerdidaPaquete() >= 0.5 && this.evaluacion.getPerdidaPaquete() <1.5) this.valoracionPerdidaPaquete ="ACEPTABLE";
		if (this.evaluacion.getPerdidaPaquete() >= 1.5) this.valoracionPerdidaPaquete ="POBRE";
	}
	
	
	public Eval getEvaluacion() {
		return evaluacion;
	}
	public void setEvaluacion(Eval evaluacion) {
		this.evaluacion = evaluacion;
	}
	public double getAnchoBandaRequerido() {
		return anchoBandaRequerido;
	}
	public void setAnchoBandaRequerido(double anchoBandaRequerido) {		
		this.anchoBandaRequerido = anchoBandaRequerido;
	}

	public Jitter getJitter(){
		return this.jitter;
	}
	public void setJitter(Jitter jitter){
	 this.jitter = jitter;
	}

	public Latencia getLatencia(){
		return this.latencia;
	}
	public void setLatencia(Latencia latencia){
	 this.latencia = latencia;
	}

	public PerdidaPaquete getPerdidaPaquete(){
		return this.perdidaPaquete;
	}
	public void setPerdidaPaquete(PerdidaPaquete perdidaPaquete){
	 this.perdidaPaquete = perdidaPaquete;
	}
	
	public String getValoracionJitter() {
		return valoracionJitter;
	}


	public void setValoracionJitter(String valoracionJitter) {
		this.valoracionJitter = valoracionJitter;
	}


	public String getValoracionLatencia() {
		return valoracionLatencia;
	}


	public void setValoracionLatencia(String valoracionLatencia) {
		this.valoracionLatencia = valoracionLatencia;
	}


	public String getValoracionPerdidaPaquete() {
		return valoracionPerdidaPaquete;
	}


	public void setValoracionPerdidaPaquete(String valoracionPerdidaPaquete) {
		this.valoracionPerdidaPaquete = valoracionPerdidaPaquete;
	}


	public String getValoracionMOSyR() {
		return valoracionMOSyR;
	}
	public void setValoracionMOSyR(String valoracionMOSyR) {
		this.valoracionMOSyR = valoracionMOSyR;
	}


	public double getR() {
		return R;
	}


	public void setR(double r) {
		R = r;
	}


	public double getMos() {
		return Mos;
	}


	public void setMos(double mos) {
		Mos = mos;
	}
	
	public String getAnchoBandaRequeridoString(){
		//double anchoEnMb = this.anchoBandaRequerido/1024;
		return new DecimalFormat("#0.00").format(anchoBandaRequerido)+" mb ";
	}
	
	public String getRString(){
		System.out.println("R "+this.R);
		return new DecimalFormat("#0.00").format(this.R);
	}
	public String getMosString(){
		System.out.println("Mos "+this.Mos);
		return new DecimalFormat("#0.00").format(this.Mos);
	}
	
	public String getValoracionAnchoBanda(){
		
		if (this.evaluacion.getAnchobanda() < this.anchoBandaRequerido )
			this.valoracionAnchoBanda="INSUFICIENTE";
		
		if (this.evaluacion.getAnchobanda()>=this.anchoBandaRequerido) 
			this.valoracionAnchoBanda="ADECUADO";
		
		return valoracionAnchoBanda;
	}
	
	public boolean esFactible(){
		System.out.println(" Disponible : "+evaluacion.getAnchobanda() + " Requerido: "+this.anchoBandaRequerido);
		return (this.evaluacion.getAnchobanda() >= this.anchoBandaRequerido);		
		 
	}

}
