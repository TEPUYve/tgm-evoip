package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.modelo.Latencia;

public class LatenciaDAO implements Serializable{
		 
	private static final long serialVersionUID = -8747349329857334875L;

	public Latencia buscarPorValor(double valor){
		Latencia latencia = null;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM latencia");
			rs = stmt.executeQuery();
			while(rs.next()) {
				latencia = new Latencia(rs.getInt("id"), rs.getString("descripcion"), rs.getInt("valor"));			}
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return latencia;
	}

}
