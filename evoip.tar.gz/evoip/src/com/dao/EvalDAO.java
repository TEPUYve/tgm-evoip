package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.ArrayList;
import java.util.List;


import com.modelo.Eval;

public class EvalDAO {
	
	public List<Eval> obtenerTodos(){
		List<Eval> lista = new ArrayList<Eval>();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM eval");
			rs = stmt.executeQuery();
			while(rs.next()) {
				
			}
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
			
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return lista;
	}

	public void agregar(Eval eval) throws SQLException{
		Connection con = null;
		Statement stmt = null;
		

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.createStatement();
			String sql = "INSERT INTO eval (descripcion,anchobanda,idcodec,idprotocolo,cantusuario,jitter,latencia,perdidapaquete) "+
			             " VALUES ('"+eval.getDescripcion()+"',"+eval.getAnchobanda()+","+eval.getCodec().getId()+
			             ","+eval.getProtocolo()+","+eval.getCantidadUsuarios()+","+eval.getJitter()+
			             ","+eval.getLatencia()+","+eval.getPerdidaPaquete()+" );";
			
			stmt.execute(sql);
			
			try {
				con.close();
			} catch (SQLException e) {				
				e.printStackTrace();
			}	
			
		} catch (SQLException e) {			
			e.printStackTrace();
			throw e;
		}finally{
			try {
				con.close();
			} catch (SQLException e) {				
				e.printStackTrace();
			}	
		}
	}
	public void actualizar(Eval eval) {	
		
	}

	public void eliminar(Eval eval) {
		
		
	}

}
