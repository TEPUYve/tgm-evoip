package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.modelo.Jitter;

public class JitterDAO implements Serializable{
		 
	private static final long serialVersionUID = -8747349329857334875L;

	public Jitter buscarPorValor(double valor){
		Jitter jitter = null;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM jitter");
			rs = stmt.executeQuery();
			while(rs.next()) {
				jitter = new Jitter(rs.getInt("id"), rs.getString("descripcion"), rs.getInt("valor"));			}
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return jitter;
	}

}
