package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.modelo.Codec;

public class CodecDAO implements Serializable{
	
	
	private static final long serialVersionUID = 4361505853896904104L;

	public List<Codec> obtenerTodos(){
		List<Codec> lista = new ArrayList<Codec>();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM codec");
			rs = stmt.executeQuery();
			while(rs.next()) {
				lista.add(new Codec(rs.getInt("id"), rs.getString("descripcion"), rs.getDouble("velocidad"),rs.getDouble("valorie")));			
		    }
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return lista;
	}

}
