package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.modelo.Protocolo;

public class ProtocoloDAO implements Serializable{
	
	
	private static final long serialVersionUID = -4016527159149933197L;

	public List<Protocolo> obtenerTodos(){
		List<Protocolo> lista = new ArrayList<Protocolo>();
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM protocolo");
			rs = stmt.executeQuery();
			while(rs.next()) {
				lista.add(new Protocolo(rs.getInt("id"), rs.getString("descripcion"), rs.getBoolean("qos")));			}
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return lista;
	}

}
