package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
	
	private  String url = "jdbc:postgresql://localhost:5432/evoip";	
	private String user = "postgres";
	private String pass = "123456";
	private Connection cn;
	private static Conexion instancia;
	     
	public static Conexion getInstancia() {
		if (instancia == null) {
			instancia = new Conexion();
		}
		return instancia;
	}

	
	public Connection getConexion() {
		try {
			Class.forName("org.postgresql.Driver");	
			cn = DriverManager.getConnection(url,user,pass);
		} catch (Exception e) {	
		          e.printStackTrace();
		}
	
      return cn;
	}

}
