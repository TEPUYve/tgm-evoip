package com.dao;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.modelo.PerdidaPaquete;

public class PerdidaPaqueteDAO implements Serializable{
		 
	private static final long serialVersionUID = -8747349329857334875L;

	public PerdidaPaquete buscarPorValor(double valor){
		PerdidaPaquete pp = null;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			con = Conexion.getInstancia().getConexion();
			stmt = con.prepareStatement("SELECT * FROM perdidapaquete");
			rs = stmt.executeQuery();
			while(rs.next()) {
				pp = new PerdidaPaquete(rs.getInt("id"), rs.getString("descripcion"), rs.getInt("valor"));			}
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		} catch (SQLException e) {			
			e.printStackTrace();
			
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}	
		}
		return pp;
	}

}
