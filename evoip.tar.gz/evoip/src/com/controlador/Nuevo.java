package com.controlador;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.WrongValueException;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zkex.zul.Jasperreport;
import org.zkoss.zul.Combobox;
import org.zkoss.zul.Comboitem;
import org.zkoss.zul.Doublebox;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Spinner;
import org.zkoss.zul.Textbox;
import org.zkoss.zul.Window;

import com.dao.CodecDAO;
import com.dao.ProtocoloDAO;
import com.modelo.Codec;
import com.modelo.Eval;
import com.modelo.Protocolo;
import com.modelo.SalidaEvaluacion;


public class Nuevo extends GenericForwardComposer {	
	private static final long serialVersionUID = -3155348260569204270L;
	private Textbox txtEtiqueta;
	private Doublebox txtAnchoBanda, txtJitter, txtLatencia, txtPerdida;
	private Spinner spnCantidadUsuarios;
	private Eval eval = null;
	private Combobox cmbCodec,cmbProtocolo;
	
	private Window vista; 
	private Window winResultadoEval;
	private double Id;
	private double R ;
	private double Mos ;	
	
	@Override
	public void doAfterCompose(Component comp) throws Exception {
		
		super.doAfterCompose(comp);
		cargarCombos();
	   
	}
	
	private void cargarCombos() {
		for (Codec codec : new CodecDAO().obtenerTodos()) {
			Comboitem cmbItem = new Comboitem(codec.toString());
			cmbItem.setAttribute("objeto",codec );
			cmbCodec.appendChild(cmbItem);
		}
		
		for (Protocolo prot : new ProtocoloDAO().obtenerTodos()) {
			Comboitem cmbItem = new Comboitem(prot.getDescripcion().toUpperCase());
			cmbItem.setAttribute("objeto",prot );
			cmbProtocolo.appendChild(cmbItem);
		}
		
		
		
	}

	
	public void onClick$opcEvaluar(){
		validar();
		getModelo();
		calcular();
		SalidaEvaluacion salidaEvaluacion  = new SalidaEvaluacion(eval, R, Mos);
		if (salidaEvaluacion.esFactible()) {		
			winResultadoEval = (Window) Executions.createComponents("evaluacion.zul", this.vista,null);
			vista.appendChild(winResultadoEval);
			Resultado controlador = (Resultado) winResultadoEval.getAttribute("controlador");
			controlador.setValores(salidaEvaluacion);
		}else{
			try {
				Messagebox.show("NECESARIO AUMENTAR EL ANCHO DE BANDA DISPONIBLE DEBIDO A QUE EL MINIMO NECESARIO ES:"+salidaEvaluacion.getAnchoBandaRequeridoString(),"Error",Messagebox.OK,Messagebox.ERROR);
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
		}
				
	}
	
	
	private void calcular() {
		Id = ( ((eval.getLatencia() + eval.getJitter())  / 2 ) / 100 ) + eval.getPerdidaPaquete();
		R = 94.2 - Id - eval.getCodec().getValorIE();
		Mos = 0.0;
		
		
		
		
	}
	
	@SuppressWarnings("rawtypes")
	public void imprimir(List<SalidaEvaluacion> salidas){
		try{
        Map parameters = new HashMap();        
        Jasperreport report = new Jasperreport();
        report.setSrc("reportes/salida.jasper");       
        report.setParameters(parameters);
        report.setDatasource(new JRBeanCollectionDataSource(salidas));       
        vista.appendChild(report);        
        setEstadoInicial();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	

	private void validar(){
		if (txtEtiqueta.getValue()==null || txtEtiqueta.getValue()=="")
			throw new WrongValueException(txtEtiqueta, "Indique un valor");
		
		if (txtAnchoBanda.getValue()==null)
			throw new WrongValueException(txtAnchoBanda, "Indique un valor");
		
		if (cmbCodec.getSelectedIndex()<0)
			throw new WrongValueException(cmbCodec, "Seleccione un valor");
		
		if (cmbProtocolo.getSelectedIndex()<0)
			throw new WrongValueException(cmbProtocolo, "Seleccione un valor");
		
		if (txtJitter.getValue()==null)
			throw new WrongValueException(txtJitter, "Indique un valor");
		
		if (txtLatencia.getValue()==null)
			throw new WrongValueException(txtLatencia, "Indique un valor");
		
		if (txtPerdida.getValue()==null)
			throw new WrongValueException(txtPerdida, "Indique un valor");
		
		if (txtPerdida.getValue()<=0.00 || txtPerdida.getValue()>100)
			throw new WrongValueException(txtPerdida, "Indique valor entre 1% y 100%");
		
		
	}
	
	private void getModelo(){
		eval = new Eval();
		eval.setDescripcion(txtEtiqueta.getValue().toUpperCase());
		eval.setAnchobanda(txtAnchoBanda.getValue());
		eval.setCantidadUsuarios(spnCantidadUsuarios.getValue());
		eval.setCodec((Codec) cmbCodec.getSelectedItem().getAttribute("objeto"));
		eval.setProtocolo((Protocolo) cmbProtocolo.getSelectedItem().getAttribute("objeto"));
		eval.setJitter(txtJitter.getValue());
		eval.setLatencia(txtLatencia.getValue());
		eval.setPerdidaPaquete(txtPerdida.getValue());
	}
	private void setEstadoInicial(){
		txtEtiqueta.setValue(null);
		txtAnchoBanda.setValue(null);
		spnCantidadUsuarios.setValue(1);
		cmbCodec.setValue(null);
		txtJitter.setValue(null);
		cmbProtocolo.setValue(null);
		txtLatencia.setValue(null);
		txtPerdida.setValue(null);
		
		
	}
	public void onClick$opcInicio(){
		 Executions.sendRedirect("index.zul");
		
	}
	
	public void onClick$opcAyuda(){
		Window ayuda =  (Window) Executions.createComponents("ayuda.zul",vista,null);
		vista.appendChild(ayuda);
	}
}
