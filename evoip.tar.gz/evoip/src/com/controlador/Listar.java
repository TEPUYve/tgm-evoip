package com.controlador;

import java.util.List;
import com.dao.EvalDAO;
import com.modelo.Eval;

import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.util.GenericForwardComposer;

public class Listar extends GenericForwardComposer {
	
	
	private static final long serialVersionUID = -6316739478331811671L;
	private EvalDAO dao = new EvalDAO();
	private Eval evalActual = new Eval();
	
	
	@Override
	public void doAfterCompose(Component comp) throws Exception {	
		super.doAfterCompose(comp);
		this.getTodasEvaluaciones();
		
	}
	
	
	public Eval getEvalActual() {
		return evalActual;
	}

	public void setEvalActual(Eval evalActual) {
		this.evalActual = evalActual;
	}

	public List<Eval> getTodasEvaluaciones(){		
		return dao.obtenerTodos();
		
	}
	
	public void onClick$update() {
		if (evalActual != null && validate(evalActual)) {        
         dao.actualizar(evalActual);
    	}
	}

	

	public void onClick$delete() {
		if (evalActual != null && validate(evalActual)) {
			dao.eliminar(evalActual);
       }
	}
	
	private boolean validate(Eval eval) {		
		return false;
	}

}
