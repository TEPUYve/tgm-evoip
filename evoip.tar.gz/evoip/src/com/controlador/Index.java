package com.controlador;



import org.zkoss.util.media.Media;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zkmax.zul.Filedownload;
import org.zkoss.zul.Fileupload;
import org.zkoss.zul.Messagebox;
import org.zkoss.zul.Window;


public class Index extends GenericForwardComposer {	
	private static final long serialVersionUID = -3155348260569204270L;
	private Window win;
	

	
	public void onClick$opcBuscar(){
		Object media = null;
		try {
			media = Fileupload.get();
		} catch (InterruptedException e) {		
			e.printStackTrace();
		}
		if (media!=null){
			if (media.toString().contains(".pdf"))				
				Filedownload.save((Media) media);				 
			else
				try {
					Messagebox.show("Solo es posible cargar archivos pdf");
				} catch (InterruptedException e) {					
					e.printStackTrace();
				}
		}else{
			try {
			Messagebox.show("Seleccione un archivo");
			} catch (InterruptedException e) {				
				e.printStackTrace();
			}
		}
	}
	public void onClick$opcAyuda(){
		Window ayuda =  (Window) Executions.createComponents("ayuda.zul",win,null);
		win.appendChild(ayuda);
	}
	
	public void onClick$opcNuevo(){
		 Executions.sendRedirect("nuevo.zul");
		
	}
	
	public void onClick$opcAcercaDe(){
		Window acercade =  (Window) Executions.createComponents("acercade.zul",win,null);
		win.appendChild(acercade);
	}
	
	

}
