package com.controlador;


import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import org.zkoss.util.media.AMedia;
import org.zkoss.zk.ui.Component;
import org.zkoss.zk.ui.Executions;
import org.zkoss.zk.ui.event.Events;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zul.Button;
import org.zkoss.zul.Iframe;
import org.zkoss.zul.Label;
import org.zkoss.zul.Window;

import com.modelo.SalidaEvaluacion;


public class Resultado extends GenericForwardComposer {	
	private static final long serialVersionUID = -3155348260569204270L;
	private Label anchoDisponible,anchoRequerido,cantidadUsuarios,cadenaCodecProcolo ;
	private Label cadenaJitter,cadenaLatencia,cadenaPerdidaPaquete,cadenaR,cadenaMOS,cadenaResultado;
	private Window winEval;
	private SalidaEvaluacion salida;
	private Button btnNueva,btnGuardar;
	private Iframe report;
	
	@Override
	public void doAfterCompose(Component comp) throws Exception {
	
		super.doAfterCompose(comp);
		this.winEval.setAttribute("controlador",this);
	}
	
	public void setValores(SalidaEvaluacion salida){
		
		this.salida = salida;		
		this.anchoDisponible.setValue(this.salida.getEvaluacion().getAnchobandaString());
		this.anchoRequerido.setValue(this.salida.getAnchoBandaRequeridoString());
		this.cantidadUsuarios.setValue(this.salida.getEvaluacion().getCantidadUsuariosString());
		this.cadenaCodecProcolo.setValue("El Codec: "+this.salida.getEvaluacion().getCodec()+" implementado bajo el protocolo "+this.salida.getEvaluacion().getProtocolo()+" en las siguientes condiciones:");
		this.cadenaJitter.setValue(this.salida.getEvaluacion().getJitterString()+ "("+ this.salida.getValoracionJitter()+")");
		this.cadenaLatencia.setValue(this.salida.getEvaluacion().getLatenciaString()+ "("+ this.salida.getValoracionLatencia()+")");
		this.cadenaPerdidaPaquete.setValue(this.salida.getEvaluacion().getPerdidaPaqueteString()+ "("+ this.salida.getValoracionPerdidaPaquete()+")");
		this.cadenaR.setValue(this.salida.getRString());
		this.cadenaMOS.setValue(this.salida.getMosString());
		this.cadenaResultado.setValue(this.salida.getValoracionMOSyR());
		
		this.btnNueva.addEventListener(Events.ON_CLICK, this);
		this.btnGuardar.addEventListener(Events.ON_CLICK, this);
		
	}
	
	public void onClick$btnNueva(){
		Executions.sendRedirect("/nuevo.zul");
	}
	
	public void onClick$btnGuardar(){
		imprimir();
		
	}
	
	private void imprimir(){		
		List<SalidaEvaluacion> salidas = new ArrayList<SalidaEvaluacion>();
		salidas.add(this.salida);
		try {
		   InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("com/reporte/salida.jasper");
           
            @SuppressWarnings("rawtypes")
			Map params = new HashMap();  
 
            byte[] buf =   JasperRunManager.runReportToPdf(is, params,new JRBeanCollectionDataSource(salidas));
                 
           
            final InputStream mediais = new ByteArrayInputStream(buf);
            final AMedia amedia =  new AMedia(this.salida.getEvaluacion().getDescripcion(), "pdf", "application/pdf", mediais);
                 
          
            report.setContent(amedia);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } 
	}

}
