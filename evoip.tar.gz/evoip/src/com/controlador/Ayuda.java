package com.controlador;


import java.io.FileNotFoundException;
import org.zkoss.zk.ui.util.GenericForwardComposer;
import org.zkoss.zkmax.zul.Filedownload;


public class Ayuda extends GenericForwardComposer {	
	private static final long serialVersionUID = -3155348260569204270L;
		
	public void onClick$opcAyudaPdf(){	
		try {
			Filedownload.save( "/EVoIPAyuda.pdf", null);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	public void onClick$opcManualUsuarioPdf(){	
		try {
			Filedownload.save( "/EVoIPManualUsuario.pdf", null);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	public void onClick$opcManualSistemaPdf(){	
		try {
			Filedownload.save( "/EVoIPManuaSistema.pdf", null);
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
	
	
	

}
